<?php
	include("mailerdip1.php");
	mailer::sendMail("otpid.is@gmail.com","C1","Nai");
	mailer::bookMail("C1","H1","2017-11-17");
	
?>